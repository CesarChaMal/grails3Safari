package hello

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
